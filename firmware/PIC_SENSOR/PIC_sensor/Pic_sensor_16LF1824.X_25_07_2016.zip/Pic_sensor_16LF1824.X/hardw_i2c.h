/* 
 * File:   hardw.h
 */

#ifndef HARDW_I2C_H
#define HARDW_I2C_H

#include<xc.h>
#include "mtypes.h"

//#define SDA_PIN PORTBbits.RB1
#define SDA_PIN  LATCbits.LATC1

//#define SCL_PIN PORTBbits.RB0	
#define SCL_PIN  LATCbits.LATC0

//#define SDA_DIR TRISBbits.RB1
#define SDA_DIR TRISCbits.TRISC1

//#define SCL_DIR TRISBbits.RB0
#define SCL_DIR TRISCbits.TRISC0

void i2c_init_hardw ();
void i2c_send_address(unsigned char address);
void i2c_send_data(unsigned char data);
unsigned char i2c_read_data(void);
void i2c_start(void);
void i2c_stop(void);
void i2c_ack(void);
void i2c_nak(void);
void i2c_idle(void);
void i2c_repstart(void);

void i2c_write_data (unsigned char address, unsigned char data);
void i2c_write_reg (unsigned char address, unsigned char reg, unsigned char data);
void i2c_read_two_regs (unsigned char address, unsigned char reg, unsigned char *data_MSB, unsigned char *data_LSB);

#endif