
//#include <pic16f1824.h>
#include "eeprom.h"
#include <xc.h>

unsigned char ReadEEPROM(unsigned char address)
{
    while(WR) continue;          
    EEADR=address;              
    EECON1 |= 0x01;             
    return EEDATA;  
}


void WriteEEPROM(unsigned char address, unsigned char data)
{
    while(WR) continue;     
    EEADR=address;         
    EEDATA=data;           
    EECON1 |= 0x04;         
    CARRY=0;                
    if(GIE) CARRY=1;       
    GIE=0;               
    EECON2=0x55;          
    EECON2=0xAA;
    EECON1 |= 0x02;          
    EECON1 &= ~0x04;      
    if(CARRY) GIE=1;            
}




 


