 #include "buffer.h"
 #include "uart.h"
 
 // global variables
 // initialization
 
 void bufferInit(cBuffer* buffer, unsigned char *start, unsigned char size)
 {
     // set start pointer of the buffer
     buffer->dataptr = start;
     buffer->size = size;
     // initialize index and length
     buffer->dataindex = 0;
     buffer->datalength = 0;
 }
 
 // access routines
 unsigned char  bufferGetFromFront(cBuffer* buffer)
 {
     unsigned char data = 0;
     
     // check to see if there's data in the buffer
     if (buffer->datalength != buffer->dataindex)
     {
         // get the first character from buffer
         data = buffer->dataptr[buffer->dataindex];
         // move index down and decrement length
         buffer->dataindex++;
         buffer->dataindex &= RX_BUF_MASK;
         //buffer->datalength--;
     }
     // return
     return data;
 }
 

 
void  RX_bufferAddToEnd(cBuffer* buffer, unsigned char data)
 {
         // make sure the buffer has room
         // save data byte at end of buffer
         buffer->dataptr[ buffer->datalength] = data;
         // increment the length
         buffer->datalength++;
         buffer->datalength &= RX_BUF_MASK;
         // return success          
 }
 

 

