
/*
 * File Name: hardw_i2c.c
*/

#include "hardw_i2c.h"
#include <xc.h>
#include <pic16f1824.h>


void i2c_init_hardw ()
{
    TRISCbits.TRISC0 = 1;            //SCL pin set as input
    TRISCbits.TRISC1 = 1;            //SDA pin set as input
    ANSELCbits.ANSC0 = 0;            //Digital I/O
    ANSELCbits.ANSC1 = 0;            //Digital I/O
     
    WPUCbits.WPUC0 = 1;              //Weak pull-up
    WPUCbits.WPUC1 = 1;              //Weak pull-up
    
    SSP1CON1bits.SSPM=0x08;          //I2C Master mode, clock = Fosc/(4 * (SSP1ADD+1))
    SSPSTAT = 0x80;                  //Disable slew rate control
    SSP1ADD = 0x09;                  //400 kHZ
    SSPCON2 = 0b000000000;           // Clear flags
  
    SSP1CON1bits.SSPEN=1;            // enable MSSP     
}


void i2c_send_address(unsigned char address)
{
    PIR1bits.SSP1IF=0;
    SSPBUF = address; 
    while(SSP1STATbits.BF); 
}

void i2c_send_data(unsigned char data)
{
    PIR1bits.SSP1IF=0;
    SSPBUF = data;
    while(SSP1STATbits.BF); 
}

unsigned char i2c_read_data(void)
{
    PIR1bits.SSP1IF=0;
    SSPCON2bits.RCEN=1;
    while(SSP1CON2bits.RCEN);                                                   // Wait for the RCEN bit to go back low before we load the data buffer
    return (SSPBUF);
}

void i2c_start(void)
{
    
    SSPCON2bits.SEN=1;
    while(SSP1CON2bits.SEN);                                                    // Wait for the SEN bit to go back low before we load the data buffer
    PIR1bits.SSP1IF=0;
}

void i2c_stop(void)
{
    PIR1bits.SSP1IF=0;
    SSPCON2bits.PEN=1;
    while(SSP1CON2bits.PEN);                                                    // Wait for the PEN bit to go back low before we load the data buffer
}

void i2c_ack(void)
{ 
   SSPCON2bits.ACKDT=0;
   SSPCON2bits.ACKEN=1;
}

void i2c_nak(void)
{
    SSPCON2bits.ACKDT=1;
    SSPCON2bits.ACKEN=1;
}

/* Waits for the I2C bus to go into Idle mode */
void i2c_idle( void )
{
	while( ( SSPCON2 & 0x1F ) | SSP1STATbits.R_nW );
}


void i2c_repstart( void )
{
	SSPCON2bits.RSEN = 1;                   // Enable Repeated Start condition
	while( SSPCON2bits.RSEN );              // Wait for condition to be sent
}

void i2c_write_data (unsigned char address, unsigned char data)
{
    i2c_idle();
    i2c_start();
    i2c_send_address(address);               //write address
    i2c_send_data(data);                     //write data
    i2c_idle();
    i2c_stop();     
}

void i2c_read_two_data (unsigned char address, unsigned char *data_MSB, unsigned char *data_LSB) 
{
      i2c_idle();
      i2c_start();
      i2c_send_address(address);              //write address 
      *data_MSB = i2c_read_data();
      i2c_idle();
      i2c_ack();
      i2c_idle();
      *data_LSB = i2c_read_data();
      i2c_idle();
      i2c_nak();
      i2c_idle();
      i2c_stop();
}



void i2c_write_reg (unsigned char address, unsigned char reg, unsigned char data)
{
     i2c_idle();
     i2c_start();
     i2c_send_address(address);               //write address
     i2c_send_data(reg);                      // write reg
     i2c_idle();
     i2c_send_data(data);                     //write data
     i2c_idle();
     i2c_stop();  
}

void i2c_read_two_regs (unsigned char address, unsigned char reg, unsigned char *data_MSB, unsigned char *data_LSB)
{
      i2c_idle();
      i2c_start();
      i2c_send_address(address);                //write address 
      i2c_send_data(reg);
      i2c_idle();
      i2c_start();
      i2c_send_address(address | 0x01);
      *data_MSB = i2c_read_data();
      i2c_idle();
      i2c_ack();
      i2c_idle();
      *data_LSB = i2c_read_data();
      i2c_idle();
      i2c_nak();
      i2c_idle();
      i2c_stop(); 
}










