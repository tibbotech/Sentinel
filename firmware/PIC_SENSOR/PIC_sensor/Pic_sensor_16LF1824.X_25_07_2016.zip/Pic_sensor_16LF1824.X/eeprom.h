/* 
 * File:   eeprom.h
 */

#ifndef EEPROM_H
#define	EEPROM_H

#include "mtypes.h"

unsigned char ReadEEPROM(unsigned char address);
void WriteEEPROM(unsigned char address, unsigned char data);


#endif	/* EEPROM_H */